AUTO FREEZE — HƯỚNG DẪN

Mục đích
- Mỗi lần chạy: gọi http://192.168.137.1:8081/mode2 một lần để BẬT.
- Chờ mặc định 3 giây.
- Gọi lại chính URL đó để TẮT.
- Có thể đổi thời gian 1–10 giây trong app hoặc trong tác vụ Shortcuts.

Cách build thành IPA trên Mac
1. Mở AutoFreeze.xcodeproj bằng Xcode.
2. Chọn target AutoFreeze > Signing & Capabilities.
3. Chọn Apple ID/Team của bạn và đổi Bundle Identifier nếu Xcode yêu cầu.
4. Cắm iPhone, chọn thiết bị rồi Run. Mở app một lần và cho phép Local Network.
5. Muốn xuất IPA: Product > Archive > Distribute App theo phương thức ký bạn đang dùng.

Cách gán vào nút Home ảo / AssistiveTouch
Cách A (khuyên dùng):
1. Mở app một lần để cấp quyền mạng nội bộ.
2. Mở Phím tắt > tạo phím tắt mới.
3. Tìm tác vụ của app "Auto Freeze" > chọn "Bật rồi tự tắt Freeze".
4. Đặt Số giây = 3.
5. Vào Cài đặt > Trợ năng > Cảm ứng > AssistiveTouch.
6. Gán thao tác bạn đang dùng cho phím tắt vừa tạo.
=> Từ giờ bấm Home ảo 1 lần: bật, đợi 3 giây, tự tắt.

Cách B (dự phòng):
- Tạo Shortcut gồm URL "autofreeze://run" > tác vụ "Mở URL".
- Gán Shortcut đó cho AssistiveTouch.

Lưu ý quan trọng
- Project giả định /mode2 là lệnh TOGGLE: gọi lần 1 bật, gọi lần 2 tắt, đúng như mô tả hiện tại của bạn.
- iPhone và máy tính phải ở đúng mạng để truy cập được 192.168.137.1:8081.
- Nếu máy tính đổi IP hoặc /mode2 không phải toggle, sửa endpoint trong AutoFreeze/FreezeController.swift.
- Ứng dụng không tự "bấm" AssistiveTouch lần hai; nó gửi trực tiếp lệnh mạng lần hai sau 3 giây, nên không cần thao tác thủ công.
