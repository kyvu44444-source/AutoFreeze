import Foundation

enum FreezeService {
    static let endpoint = URL(string: "http://192.168.137.1:8081/mode2")!

    static func sendToggle() async throws {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "GET"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.timeoutInterval = 5
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")

        let (_, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse,
           !(200...399).contains(http.statusCode) {
            throw URLError(.badServerResponse)
        }
    }
}

@MainActor
final class FreezeController: ObservableObject {
    static let shared = FreezeController()

    @Published var status = "Sẵn sàng"
    @Published var isRunning = false

    private init() {}

    func runCycle(delay overrideDelay: Int? = nil) {
        guard !isRunning else { return }

        let savedDelay = UserDefaults.standard.integer(forKey: "delaySeconds")
        let delay = overrideDelay ?? (savedDelay > 0 ? savedDelay : 3)

        Task {
            isRunning = true
            defer { isRunning = false }

            do {
                status = "Đang bật…"
                try await FreezeService.sendToggle()

                status = "Đã bật — tự tắt sau \(delay) giây"
                try await Task.sleep(nanoseconds: UInt64(delay) * 1_000_000_000)

                status = "Đang tắt…"
                try await FreezeService.sendToggle()
                status = "Đã tự tắt"
            } catch is CancellationError {
                status = "Đã hủy"
            } catch {
                status = "Lỗi kết nối: \(error.localizedDescription)"
            }
        }
    }
}
