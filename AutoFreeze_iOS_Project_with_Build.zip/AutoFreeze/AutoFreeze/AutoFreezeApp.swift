import SwiftUI

@main
struct AutoFreezeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
