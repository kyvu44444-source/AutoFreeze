import SwiftUI

@main
struct AutoFreezeApp: App {
    @StateObject private var controller = FreezeController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(controller)
                .onOpenURL { url in
                    guard url.scheme == "autofreeze", url.host == "run" else { return }
                    controller.runCycle()
                }
        }
    }
}
