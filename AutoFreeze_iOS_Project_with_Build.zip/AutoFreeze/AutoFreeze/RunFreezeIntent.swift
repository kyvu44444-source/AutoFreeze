import AppIntents
import Foundation

struct RunFreezeIntent: AppIntent {
    static var title: LocalizedStringResource = "Bật rồi tự tắt Freeze"
    static var description = IntentDescription("Gửi lệnh Freeze, chờ vài giây rồi tự gửi lại lệnh để tắt.")
    static var openAppWhenRun: Bool = false

    @Parameter(title: "Số giây", default: 3, inclusiveRange: (1, 10))
    var seconds: Int

    static var parameterSummary: some ParameterSummary {
        Summary("Bật Freeze rồi tự tắt sau \(.$seconds) giây")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        try await FreezeService.sendToggle()
        try await Task.sleep(nanoseconds: UInt64(seconds) * 1_000_000_000)
        try await FreezeService.sendToggle()
        return .result(dialog: "Freeze đã tự tắt.")
    }
}

struct AutoFreezeShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: RunFreezeIntent(),
            phrases: [
                "Chạy \(.applicationName)",
                "Bật Freeze bằng \(.applicationName)"
            ],
            shortTitle: "Freeze tự tắt",
            systemImageName: "snowflake"
        )
    }
}
