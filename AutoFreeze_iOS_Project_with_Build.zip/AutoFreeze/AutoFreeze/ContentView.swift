import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var controller: FreezeController
    @AppStorage("delaySeconds") private var delaySeconds: Int = 3

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Image(systemName: controller.isRunning ? "snowflake.circle.fill" : "snowflake.circle")
                    .font(.system(size: 72))

                Text(controller.status)
                    .font(.headline)
                    .multilineTextAlignment(.center)

                Stepper("Tự tắt sau: \(delaySeconds) giây", value: $delaySeconds, in: 1...10)
                    .disabled(controller.isRunning)

                Button {
                    controller.runCycle()
                } label: {
                    Text(controller.isRunning ? "ĐANG CHẠY…" : "BẬT RỒI TỰ TẮT")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .disabled(controller.isRunning)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Địa chỉ đang dùng")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(FreezeService.endpoint.absoluteString)
                        .font(.system(.footnote, design: .monospaced))
                        .textSelection(.enabled)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Spacer()
            }
            .padding()
            .navigationTitle("Auto Freeze")
        }
    }
}
