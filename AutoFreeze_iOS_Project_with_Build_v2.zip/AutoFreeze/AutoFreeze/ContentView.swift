import SwiftUI
import Foundation

struct ContentView: View {
    @State private var status = "Sẵn sàng"
    @State private var isRunning = false
    @AppStorage("delaySeconds") private var delaySeconds = 3

    private let endpoint = URL(string: "http://192.168.137.1:8081/mode2")!

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Image(systemName: isRunning ? "snowflake.circle.fill" : "snowflake.circle")
                    .font(.system(size: 72))

                Text(status)
                    .font(.headline)
                    .multilineTextAlignment(.center)

                Stepper("Tự tắt sau: \(delaySeconds) giây", value: $delaySeconds, in: 1...10)
                    .disabled(isRunning)

                Button {
                    runCycle()
                } label: {
                    Text(isRunning ? "ĐANG CHẠY…" : "BẬT RỒI TỰ TẮT")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .disabled(isRunning)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Địa chỉ đang dùng")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(endpoint.absoluteString)
                        .font(.system(.footnote, design: .monospaced))
                        .textSelection(.enabled)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Text("Mở app hoặc gọi autofreeze://run để chạy: bật → chờ → tự tắt.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                Spacer()
            }
            .padding()
            .navigationTitle("Auto Freeze")
        }
        .onAppear {
            runCycle()
        }
        .onOpenURL { url in
            guard url.scheme == "autofreeze", url.host == "run" else { return }
            runCycle()
        }
    }

    @MainActor
    private func runCycle() {
        guard !isRunning else { return }
        let seconds = max(1, min(delaySeconds, 10))
        isRunning = true

        Task {
            defer { isRunning = false }
            do {
                status = "Đang bật…"
                try await sendToggle()

                status = "Đã bật — tự tắt sau \(seconds) giây"
                try await Task.sleep(nanoseconds: UInt64(seconds) * 1_000_000_000)

                status = "Đang tắt…"
                try await sendToggle()
                status = "Đã tự tắt"
            } catch is CancellationError {
                status = "Đã hủy"
            } catch {
                status = "Lỗi kết nối: \(error.localizedDescription)"
            }
        }
    }

    private func sendToggle() async throws {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "GET"
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 5
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")

        let (_, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...399).contains(http.statusCode) {
            throw URLError(.badServerResponse)
        }
    }
}
