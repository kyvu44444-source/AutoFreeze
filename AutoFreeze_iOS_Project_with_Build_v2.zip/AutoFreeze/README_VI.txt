AutoFreeze v1.1 - bản tối giản để build ổn định

Cơ chế:
- Mở app: tự gửi GET tới http://192.168.137.1:8081/mode2
- Chờ 3 giây (có thể đổi 1-10 giây trong app)
- Tự gửi GET lại cùng URL để tắt
- Có URL scheme autofreeze://run để dùng trong Shortcuts

Bản này cố ý KHÔNG dùng AppIntents/Combine/ObservableObject để tránh lỗi compile trước đó.
Yêu cầu iOS 16.0+.
